#include <vector>

using namespace std;	//to avoid having to write std::vector
using dvector = vector<double>;	

int main() 
{
	const int ni = 21;
	dvector phi(ni);
	dvector rho(ni);
	dvector ef(ni);
	
	/*rest of the code*/

	return 0;			//normal exit
}
