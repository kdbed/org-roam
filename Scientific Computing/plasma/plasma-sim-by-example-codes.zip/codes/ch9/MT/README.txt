Parallel version of Chapter 2 example
