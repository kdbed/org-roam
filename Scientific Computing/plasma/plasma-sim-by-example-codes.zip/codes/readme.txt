This folder contains code samples from L. Brieda, "Plasma Simulations by Example", CRC Press 2019
https://www.particleincell.com/plasma-by-example/
