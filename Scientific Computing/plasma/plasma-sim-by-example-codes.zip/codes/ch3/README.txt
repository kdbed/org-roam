ver1: basic version with non-matrix GS solver
list: ver1 version with a linked  list for particles
ver2: matrix-based GS/PCG solver 
