.. _codedoc:

Code Documentation
==================

openfermion.hamiltonians
------------------------
.. automodule:: openfermion.hamiltonians
    :members:
    :special-members: __init__
    :imported-members:

openfermion.measurements
------------------------

.. automodule:: openfermion.measurements
    :members:
    :special-members: __init__
    :imported-members:

openfermion.ops
---------------

.. automodule:: openfermion.ops
    :members:
    :special-members: __init__
    :imported-members:
    :show-inheritance:

openfermion.transforms
----------------------

.. automodule:: openfermion.transforms
    :members:
    :special-members: __init__
    :imported-members:

openfermion.utils
-----------------

.. automodule:: openfermion.utils
    :members:
    :special-members: __init__
    :imported-members:
