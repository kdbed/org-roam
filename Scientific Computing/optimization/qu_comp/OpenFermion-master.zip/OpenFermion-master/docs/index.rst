.. title:: Overview

Welcome to the docs
===================

Contents
        * :ref:`codedoc`: The code documentation of OpenFermion.

.. toctree::
        :maxdepth: 2
        :hidden:

        openfermion
