D-Wave welcomes contributions to Ocean projects.

See how to contribute at `Ocean Contributors <http://dw-docs.readthedocs.io/en/latest/CONTRIBUTING.html>`_.
