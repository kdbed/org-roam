The software in this directory (Cirq/examples/) is not included in the packaged library. Anyone is free to copy, modify, use, or publish this example code.
