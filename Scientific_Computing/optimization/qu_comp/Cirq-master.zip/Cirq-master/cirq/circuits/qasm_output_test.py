# Copyright 2018 The Cirq Developers
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from typing import List

import re
import pytest

import numpy as np

import cirq
from cirq.circuits.qasm_output import QasmUGate, QasmTwoQubitGate


def _make_qubits(n):
    return [cirq.NamedQubit('q{}'.format(i)) for i in range(n)]


def test_u_gate_repr():
    gate = QasmUGate(0.1, 0.2, 0.3)
    assert repr(gate) == 'cirq.QasmUGate(0.1, 0.2, 0.3)'


def test_qasm_two_qubit_gate_repr():
    cirq.testing.assert_equivalent_repr(QasmTwoQubitGate.from_matrix(
        cirq.testing.random_unitary(4)))


def test_qasm_u_qubit_gate_unitary():
    u = cirq.testing.random_unitary(2)
    g = QasmUGate.from_matrix(u)
    cirq.testing.assert_allclose_up_to_global_phase(cirq.unitary(g),
                                                    u,
                                                    atol=1e-7)


def test_qasm_two_qubit_gate_unitary():
    u = cirq.testing.random_unitary(4)
    g = QasmTwoQubitGate.from_matrix(u)
    np.testing.assert_allclose(cirq.unitary(g), u)


def test_empty_circuit():
    q0, = _make_qubits(1)
    output = cirq.QasmOutput((), (q0,))
    assert (str(output) ==
            """OPENQASM 2.0;
include "qelib1.inc";


// Qubits: [q0]
qreg q[1];
""")


def test_header():
    q0, = _make_qubits(1)
    output = cirq.QasmOutput((), (q0,), header="""My test circuit
Device: Bristlecone""")
    assert (str(output) ==
            """// My test circuit
// Device: Bristlecone

OPENQASM 2.0;
include "qelib1.inc";


// Qubits: [q0]
qreg q[1];
""")

    output = cirq.QasmOutput((), (q0,), header="""
My test circuit
Device: Bristlecone
""")
    assert (str(output) ==
            """//
// My test circuit
// Device: Bristlecone
//

OPENQASM 2.0;
include "qelib1.inc";


// Qubits: [q0]
qreg q[1];
""")


def test_single_gate_no_parameter():
    q0, = _make_qubits(1)
    output = cirq.QasmOutput((cirq.X(q0),), (q0,))
    assert (str(output) ==
            """OPENQASM 2.0;
include "qelib1.inc";


// Qubits: [q0]
qreg q[1];


x q[0];
""")


def test_single_gate_with_parameter():
    q0, = _make_qubits(1)
    output = cirq.QasmOutput((cirq.X(q0) ** 0.25,), (q0,))
    assert (str(output) ==
            """OPENQASM 2.0;
include "qelib1.inc";


// Qubits: [q0]
qreg q[1];


rx(pi*0.25) q[0];
""")


def test_h_gate_with_parameter():
    q0, = _make_qubits(1)
    output = cirq.QasmOutput((cirq.H(q0) ** 0.25,), (q0,))
    assert (str(output) ==
            """OPENQASM 2.0;
include "qelib1.inc";


// Qubits: [q0]
qreg q[1];


ry(pi*0.25) q[0];
rx(pi*0.25) q[0];
ry(pi*-0.25) q[0];
""")


def test_precision():
    q0, = _make_qubits(1)
    output = cirq.QasmOutput((cirq.X(q0) ** 0.1234567,), (q0,), precision=3)
    assert (str(output) ==
            """OPENQASM 2.0;
include "qelib1.inc";


// Qubits: [q0]
qreg q[1];


rx(pi*0.123) q[0];
""")


def test_version():
    q0, = _make_qubits(1)
    with pytest.raises(ValueError):
        output = cirq.QasmOutput((), (q0,), version='3.0')
        _ = str(output)


def test_save_to_file():
    q0, = _make_qubits(1)
    output = cirq.QasmOutput((), (q0,))
    with cirq.testing.TempFilePath() as file_path:
        output.save(file_path)
        with open(file_path, 'r') as f:
            file_content = f.read()
    assert (file_content ==
            """OPENQASM 2.0;
include "qelib1.inc";


// Qubits: [q0]
qreg q[1];
""")


def test_unsupported_operation():
    q0, = _make_qubits(1)

    class UnsupportedOperation(cirq.Operation):
        qubits = (q0,)
        with_qubits = NotImplemented

    output = cirq.QasmOutput((UnsupportedOperation(),), (q0,))
    with pytest.raises(ValueError):
        _ = str(output)


def _all_operations(q0, q1, q2, q3, q4, include_measurments=True):
    class DummyOperation(cirq.Operation):
        qubits = (q0,)
        with_qubits = NotImplemented

        def _qasm_(self, args: cirq.QasmArgs) -> str:
            return '// Dummy operation\n'

        def _decompose_(self):
            # Only used by test_output_unitary_same_as_qiskit
            return ()  # coverage: ignore

    class DummyCompositeOperation(cirq.Operation):
        qubits = (q0,)
        with_qubits = NotImplemented

        def _decompose_(self):
            return cirq.X(self.qubits[0])

        def __repr__(self):
            return 'DummyCompositeOperation()'

    return (
        cirq.Z(q0),
        cirq.Z(q0) ** .625,
        cirq.Y(q0),
        cirq.Y(q0) ** .375,
        cirq.X(q0),
        cirq.X(q0) ** .875,
        cirq.H(q1),
        cirq.CZ(q0, q1),
        cirq.CZ(q0, q1) ** 0.25,  # Requires 2-qubit decomposition
        cirq.CNOT(q0, q1),
        cirq.CNOT(q0, q1) ** 0.5,  # Requires 2-qubit decomposition
        cirq.SWAP(q0, q1),
        cirq.SWAP(q0, q1) ** 0.75,  # Requires 2-qubit decomposition

        cirq.CCZ(q0, q1, q2),
        cirq.CCX(q0, q1, q2),
        cirq.CCZ(q0, q1, q2)**0.5,
        cirq.CCX(q0, q1, q2)**0.5,
        cirq.CSWAP(q0, q1, q2),

        cirq.ISWAP(q2, q0),  # Requires 2-qubit decomposition

        cirq.PhasedXPowGate(phase_exponent=0.111, exponent=0.25).on(q1),
        cirq.PhasedXPowGate(phase_exponent=0.333, exponent=0.5).on(q1),
        cirq.PhasedXPowGate(phase_exponent=0.777, exponent=-0.5).on(q1),

        (
            cirq.measure(q0, key='xX'),
            cirq.measure(q2, key='x_a'),
            cirq.measure(q1, key='x?'),
            cirq.measure(q3, key='X'),
            cirq.measure(q4, key='_x'),
            cirq.measure(q2, key='x_a'),
            cirq.measure(q1, q2, q3, key='multi', invert_mask=(False, True))
        ) if include_measurments else (),

        DummyOperation(),
        DummyCompositeOperation(),
    )


def test_output_parseable_by_qiskit():
    qubits = tuple(_make_qubits(5))
    operations = _all_operations(*qubits)
    output = cirq.QasmOutput(operations, qubits,
                             header='Generated from Cirq',
                             precision=10)
    text = str(output)

    # coverage: ignore
    try:
        # We don't want to require qiskit as a dependency but
        # if Qiskit is installed, test QASM output against it.
        import qiskit  # type: ignore
    except ImportError:
        return

    assert qiskit.qasm.Qasm(data=text).parse().qasm() is not None


def test_output_unitary_same_as_qiskit():
    qubits = tuple(_make_qubits(5))
    operations = _all_operations(*qubits, include_measurments=False)
    output = cirq.QasmOutput(operations, qubits,
                             header='Generated from Cirq',
                             precision=10)
    text = str(output)

    # coverage: ignore
    try:
        # We don't want to require qiskit as a dependency but
        # if Qiskit is installed, test QASM output against it.
        import qiskit  # type: ignore
    except ImportError:
        return

    circuit = cirq.Circuit.from_ops(operations)
    cirq_unitary = circuit.to_unitary_matrix(qubit_order=qubits)

    result = qiskit.execute(
        qiskit.load_qasm_string(text),
        backend=qiskit.Aer.get_backend('unitary_simulator'))
    qiskit_unitary = result.result().get_unitary()
    qiskit_unitary = _reorder_indices_of_matrix(
            qiskit_unitary,
            list(reversed(range(len(qubits)))))

    cirq.testing.assert_allclose_up_to_global_phase(
        cirq_unitary, qiskit_unitary, rtol=1e-8, atol=1e-8)


def test_fails_on_big_unknowns():
    class UnrecognizedGate(cirq.ThreeQubitGate):
        pass
    c = cirq.Circuit.from_ops(
        UnrecognizedGate().on(*cirq.LineQubit.range(3)))
    with pytest.raises(ValueError, match='Cannot output operation as QASM'):
        _ = c.to_qasm()


def test_output_format():
    def filter_unpredictable_numbers(text):
        return re.sub(r'u3\(.+\)', r'u3(<not-repeatable>)', text)

    qubits = tuple(_make_qubits(5))
    operations = _all_operations(*qubits)
    output = cirq.QasmOutput(operations, qubits,
                             header='Generated from Cirq!',
                             precision=5)
    assert (filter_unpredictable_numbers(str(output)) ==
            filter_unpredictable_numbers(
        """// Generated from Cirq!

OPENQASM 2.0;
include "qelib1.inc";


// Qubits: [q0, q1, q2, q3, q4]
qreg q[5];
creg m_xX[1];
creg m_x_a[1];
creg m0[1];  // Measurement: x?
creg m_X[1];
creg m__x[1];
creg m_multi[3];


z q[0];
rz(pi*0.625) q[0];
y q[0];
ry(pi*0.375) q[0];
x q[0];
rx(pi*0.875) q[0];
h q[1];
cz q[0],q[1];

// Gate: CZ**0.25
u3(pi*0.5,pi*1.0,pi*0.75) q[0];
u3(pi*0.5,pi*1.0,pi*0.25) q[1];
rx(pi*0.5) q[0];
cx q[0],q[1];
rx(pi*0.375) q[0];
ry(pi*0.5) q[1];
cx q[1],q[0];
rx(pi*-0.5) q[1];
rz(pi*0.5) q[1];
cx q[0],q[1];
u3(pi*0.5,pi*0.375,0) q[0];
u3(pi*0.5,pi*0.875,0) q[1];

cx q[0],q[1];

// Gate: CNOT**0.5
ry(pi*-0.5) q[1];
u3(pi*0.5,0,pi*0.25) q[0];
u3(pi*0.5,0,pi*0.75) q[1];
rx(pi*0.5) q[0];
cx q[0],q[1];
rx(pi*0.25) q[0];
ry(pi*0.5) q[1];
cx q[1],q[0];
rx(pi*-0.5) q[1];
rz(pi*0.5) q[1];
cx q[0],q[1];
u3(pi*0.5,pi*1.0,pi*1.0) q[0];
u3(pi*0.5,pi*0.5,pi*1.0) q[1];
ry(pi*0.5) q[1];

swap q[0],q[1];

// Gate: SWAP**0.75
cx q[0],q[1];
ry(pi*-0.5) q[0];
u3(pi*0.5,0,pi*0.45919) q[1];
u3(pi*0.5,0,pi*1.95919) q[0];
rx(pi*0.5) q[1];
cx q[1],q[0];
rx(pi*0.125) q[1];
ry(pi*0.5) q[0];
cx q[0],q[1];
rx(pi*-0.5) q[0];
rz(pi*0.5) q[0];
cx q[1],q[0];
u3(pi*0.5,pi*0.91581,pi*1.0) q[1];
u3(pi*0.5,pi*1.41581,pi*1.0) q[0];
ry(pi*0.5) q[0];
cx q[0],q[1];

h q[2];
ccx q[0],q[1],q[2];
h q[2];
ccx q[0],q[1],q[2];

// Gate: CCZ**0.5
rz(pi*0.125) q[0];
rz(pi*0.125) q[1];
rz(pi*0.125) q[2];
cx q[0],q[1];
cx q[1],q[2];
rz(pi*-0.125) q[1];
rz(pi*0.125) q[2];
cx q[0],q[1];
cx q[1],q[2];
rz(pi*-0.125) q[2];
cx q[0],q[1];
cx q[1],q[2];
rz(pi*-0.125) q[2];
cx q[0],q[1];
cx q[1],q[2];

// Gate: TOFFOLI**0.5
h q[2];
rz(pi*0.125) q[0];
rz(pi*0.125) q[1];
rz(pi*0.125) q[2];
cx q[0],q[1];
cx q[1],q[2];
rz(pi*-0.125) q[1];
rz(pi*0.125) q[2];
cx q[0],q[1];
cx q[1],q[2];
rz(pi*-0.125) q[2];
cx q[0],q[1];
cx q[1],q[2];
rz(pi*-0.125) q[2];
cx q[0],q[1];
cx q[1],q[2];
h q[2];

cswap q[0],q[1],q[2];

// Gate: ISWAP
cx q[2],q[0];
h q[2];
cx q[0],q[2];
rz(pi*0.5) q[2];
cx q[0],q[2];
rz(pi*-0.5) q[2];
h q[2];
cx q[2],q[0];

u3(pi*-0.25, pi*0.611, pi*-0.611) q[1];
u2(pi*-0.167, pi*0.167) q[1];
u2(pi*1.277, pi*-1.277) q[1];
measure q[0] -> m_xX[0];
measure q[2] -> m_x_a[0];
measure q[1] -> m0[0];
measure q[3] -> m_X[0];
measure q[4] -> m__x[0];
measure q[2] -> m_x_a[0];
measure q[1] -> m_multi[0];
x q[2];  // Invert the following measurement
measure q[2] -> m_multi[1];
measure q[3] -> m_multi[2];
// Dummy operation

// Operation: DummyCompositeOperation()
x q[0];
"""))


def _reorder_indices_of_matrix(matrix: np.ndarray, new_order: List[int]):
    num_qubits = matrix.shape[0].bit_length() - 1
    matrix = np.reshape(matrix, (2,) * 2 * num_qubits)
    all_indices = range(2*num_qubits)
    new_input_indices = new_order
    new_output_indices = [i + num_qubits for i in new_input_indices]
    matrix = np.moveaxis(
            matrix,
            all_indices,
            new_input_indices + new_output_indices
    )
    matrix = np.reshape(matrix, (2**num_qubits, 2**num_qubits))
    return matrix
